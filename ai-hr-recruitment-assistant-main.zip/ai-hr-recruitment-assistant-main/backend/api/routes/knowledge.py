from fastapi import APIRouter,Depends,Header,HTTPException,UploadFile,File
from api.routes.auth import current_user
from database.session import get_db
from services.rag_service import ingest_chroma
from pathlib import Path
router=APIRouter()
@router.get("")
def list_kb(db=Depends(get_db),authorization:str|None=Header(None)):
    current_user(db,authorization); kb=Path(__file__).resolve().parents[2]/"knowledge_base"
    return {"files":[str(p.relative_to(kb)) for p in kb.rglob("*") if p.is_file()]}
@router.post("/ingest")
def ingest(db=Depends(get_db),authorization:str|None=Header(None)):
    current_user(db,authorization)
    try:return {"status":"ok","documents":ingest_chroma()}
    except Exception as e: raise HTTPException(503,str(e))

@router.post("/upload")
async def upload(file:UploadFile=File(...),db=Depends(get_db),authorization:str|None=Header(None)):
    current_user(db,authorization)
    if not file.filename or Path(file.filename).suffix.lower() not in {".txt",".md"}:
        raise HTTPException(400,"Knowledge files must be .txt or .md.")
    kb=Path(__file__).resolve().parents[2]/"knowledge_base"
    target=kb/"company_info"/Path(file.filename).name
    target.write_bytes(await file.read())
    return {"status":"uploaded","path":str(target.relative_to(kb))}
