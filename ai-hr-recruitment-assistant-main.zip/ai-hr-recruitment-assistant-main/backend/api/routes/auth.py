from fastapi import APIRouter,Depends,HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database.session import get_db
from models import User
from passlib.context import CryptContext
from jose import jwt
import os
router=APIRouter(); pwd=CryptContext(schemes=["pbkdf2_sha256"],deprecated="auto")
class Auth(BaseModel): email:str; password:str; full_name:str|None=None
def token(u): return jwt.encode({"sub":str(u.id),"email":u.email},os.getenv("JWT_SECRET","dev-secret"),algorithm="HS256")
def current_user(db:Session, authorization:str|None=None):
    if not authorization: raise HTTPException(401,"Authentication required.")
    try:
        raw=authorization.split(" ",1)[1]; uid=jwt.decode(raw,os.getenv("JWT_SECRET","dev-secret"),algorithms=["HS256"])["sub"]
        u=db.get(User,int(uid))
        if not u: raise ValueError()
        return u
    except Exception: raise HTTPException(401,"Invalid or expired token.")
@router.post("/register")
def register(a:Auth,db:Session=Depends(get_db)):
    if db.query(User).filter_by(email=a.email).first(): raise HTTPException(409,"Email already registered.")
    u=User(email=a.email,hashed_password=pwd.hash(a.password),full_name=a.full_name or a.email.split("@")[0])
    db.add(u);db.commit();db.refresh(u);return {"token":token(u),"user":{"id":u.id,"email":u.email,"full_name":u.full_name,"role":u.role}}
@router.post("/login")
def login(a:Auth,db:Session=Depends(get_db)):
    u=db.query(User).filter_by(email=a.email).first()
    if not u or not pwd.verify(a.password,u.hashed_password): raise HTTPException(401,"Invalid email or password.")
    return {"token":token(u),"user":{"id":u.id,"email":u.email,"full_name":u.full_name,"role":u.role}}
