from fastapi import APIRouter,Depends,HTTPException,Header
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database.session import get_db
from models import Job
from api.routes.auth import current_user
from services.pdf_service import save_upload
from services.extraction_service import analyze_jd
from fastapi import UploadFile,File
router=APIRouter()
def user(db=Depends(get_db),authorization: str|None=Header(None)): return current_user(db,authorization)
class JobCreate(BaseModel):
    job_title:str; required_skills:list[str]=[]; preferred_skills:list[str]=[]; experience_required:str|None=None; education_required:str|None=None; responsibilities:list[str]=[]; certifications_required:list[str]=[]
@router.post("")
def create(x:JobCreate,db:Session=Depends(get_db),u=Depends(user)):
    j=Job(owner_id=u.id,**x.model_dump());db.add(j);db.commit();db.refresh(j);return serialize(j)
@router.get("")
def list_jobs(db:Session=Depends(get_db),u=Depends(user)): return [serialize(j) for j in db.query(Job).filter_by(owner_id=u.id).order_by(Job.created_at.desc()).all()]
@router.get("/{job_id}")
def get_job(job_id:int,db:Session=Depends(get_db),u=Depends(user)):
    j=db.query(Job).filter_by(id=job_id,owner_id=u.id).first()
    if not j: raise HTTPException(404,"Job not found.")
    return serialize(j)
@router.post("/upload")
async def upload_job(file:UploadFile=File(...),db:Session=Depends(get_db),u=Depends(user)):
    path,text=await save_upload(file,"job_descriptions"); data=analyze_jd(text)
    j=Job(owner_id=u.id,job_title=data["job_title"],raw_description_text=text,source_file_path=str(path),required_skills=data["required_skills"],preferred_skills=data["preferred_skills"],experience_required=data["experience_required"],education_required=data["education_required"],responsibilities=data["responsibilities"],certifications_required=data["certifications_required"],technical_requirements=data["technical_requirements"])
    db.add(j);db.commit();db.refresh(j);return serialize(j)
def serialize(j): return {"id":j.id,"job_title":j.job_title,"required_skills":j.required_skills or [],"preferred_skills":j.preferred_skills or [],"experience_required":j.experience_required,"education_required":j.education_required,"status":j.status,"created_at":j.created_at}

@router.put("/{job_id}")
def update_job(job_id:int,x:JobCreate,db:Session=Depends(get_db),u=Depends(user)):
    j=db.query(Job).filter_by(id=job_id,owner_id=u.id).first()
    if not j: raise HTTPException(404,"Job not found.")
    for k,v in x.model_dump().items(): setattr(j,k,v)
    db.commit();db.refresh(j);return serialize(j)
@router.delete("/{job_id}")
def delete_job(job_id:int,db:Session=Depends(get_db),u=Depends(user)):
    j=db.query(Job).filter_by(id=job_id,owner_id=u.id).first()
    if not j: raise HTTPException(404,"Job not found.")
    db.delete(j);db.commit();return {"status":"deleted"}
