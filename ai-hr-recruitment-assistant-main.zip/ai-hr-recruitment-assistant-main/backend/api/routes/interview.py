from fastapi import APIRouter,Depends,Header,HTTPException
from sqlalchemy.orm import Session
from database.session import get_db
from models import Candidate,InterviewQuestion
from api.routes.auth import current_user
from services.llm_service import interview_questions
router=APIRouter()
@router.post("/candidates/{candidate_id}/generate")
def generate(candidate_id:int,db:Session=Depends(get_db),authorization:str|None=Header(None)):
    u=current_user(db,authorization); c=db.get(Candidate,candidate_id)
    if not c or c.job.owner_id!=u.id: raise HTTPException(404,"Candidate not found.")
    data={"skills":[s.skill_name for s in c.skills],"projects":[{"title":p.title,"description":p.description} for p in c.projects]}
    qs=interview_questions({"required_skills":c.job.required_skills or []},data, (c.match.missing_skills if c.match else []))
    if not qs: qs=[f"Technical: How would you demonstrate your knowledge of {s}?" for s in (c.job.required_skills or [])[:5]]
    cats=["Technical","Project","Experience","Behavioral","Job-specific"]
    rows=[]
    for i,q in enumerate(qs):
        r=InterviewQuestion(candidate_id=c.id,job_id=c.job_id,category=cats[i%5],difficulty="medium",question_text=q);db.add(r);rows.append(q)
    db.commit();return {"questions":rows}
@router.get("/candidates/{candidate_id}")
def get(candidate_id:int,db:Session=Depends(get_db),authorization:str|None=Header(None)):
    u=current_user(db,authorization);c=db.get(Candidate,candidate_id)
    if not c or c.job.owner_id!=u.id: raise HTTPException(404,"Candidate not found.")
    return [{"id":q.id,"category":q.category,"difficulty":q.difficulty,"question":q.question_text} for q in c.interview_questions]
