"""
Database health-check route.

This is what actually proves Phase 2 works end-to-end: it opens a
real session through get_db(), inspects the live schema, and returns
which tables exist. If the database is unreachable it returns a
clean 503 instead of leaking a raw stack trace to the client.
"""
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import inspect
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from database.session import DATABASE_URL, get_db
from schemas.health import DBHealthResponse

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/db-health", response_model=DBHealthResponse)
def db_health_check(db: Session = Depends(get_db)):
    """Check that the database is reachable and list its tables."""
    try:
        inspector = inspect(db.get_bind())
        tables = sorted(inspector.get_table_names())
        db_type = "sqlite" if DATABASE_URL.startswith("sqlite") else "other"

        return DBHealthResponse(
            status="ok",
            database_url_type=db_type,
            tables_found=tables,
            table_count=len(tables),
        )
    except SQLAlchemyError as exc:
        logger.error(f"Database health check failed: {exc}")
        raise HTTPException(status_code=503, detail="Database connection failed.") from exc
