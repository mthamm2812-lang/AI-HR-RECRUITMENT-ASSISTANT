from fastapi import APIRouter,Depends,Header
from sqlalchemy.orm import Session
from database.session import get_db
from models import Job,Candidate,Match
from api.routes.auth import current_user
router=APIRouter()
@router.get("")
def dashboard(db:Session=Depends(get_db),authorization:str|None=Header(None)):
    u=current_user(db,authorization); jobs=db.query(Job).filter_by(owner_id=u.id).all(); ids=[j.id for j in jobs]
    ms=db.query(Match).filter(Match.job_id.in_(ids)).all() if ids else []
    return {"total_jobs":len(jobs),"total_candidates":sum(len(j.candidates) for j in jobs),"shortlisted":sum(m.recommendation=="SHORTLIST" for m in ms),"review":sum(m.recommendation=="REVIEW" for m in ms),"not_recommended":sum(m.recommendation=="NOT RECOMMENDED" for m in ms),"rankings":[{"candidate_id":m.candidate_id,"name":m.candidate.name,"score":m.overall_score,"recommendation":m.recommendation} for m in sorted(ms,key=lambda x:x.overall_score or 0,reverse=True)]}
