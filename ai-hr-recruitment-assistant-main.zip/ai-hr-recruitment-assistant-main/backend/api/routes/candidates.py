from fastapi import APIRouter,Depends,HTTPException,Header,UploadFile,File
from sqlalchemy.orm import Session
from database.session import get_db
from models import *
from api.routes.auth import current_user
from services.pdf_service import save_upload
from services.extraction_service import analyze_resume
from graph.recruitment_graph import graph
router=APIRouter()
def user(db=Depends(get_db),authorization: str|None=Header(None)): return current_user(db,authorization)
def job_for(db,jid,u):
    j=db.query(Job).filter_by(id=jid,owner_id=u.id).first()
    if not j: raise HTTPException(404,"Job not found.")
    return j
@router.post("/jobs/{job_id}/resumes")
async def upload_resumes(job_id:int,files:list[UploadFile]=File(...),db:Session=Depends(get_db),u=Depends(user)):
    j=job_for(db,job_id,u); out=[]
    for f in files:
        path,text=await save_upload(f,"resumes"); data=analyze_resume(text)
        c=Candidate(job_id=j.id,name=data["name"],email=data["email"],phone=data["phone"],resume_file_path=str(path),raw_resume_text=text,education=data["education"],status="analyzed")
        db.add(c);db.flush()
        for s in data["skills"]: db.add(CandidateSkill(candidate_id=c.id,skill_name=s,skill_type="technical"))
        for e in data["experience"]: db.add(CandidateExperience(candidate_id=c.id,role_title=e.get("role_title"),duration=e.get("duration"),description=e.get("description")))
        for pr in data["projects"]: db.add(CandidateProject(candidate_id=c.id,title=pr.get("title"),description=pr.get("description"),technologies_used=pr.get("technologies_used",[])))
        db.commit(); db.refresh(c); out.append(serialize(c))
    return out
@router.get("/jobs/{job_id}/candidates")
def candidates(job_id:int,db:Session=Depends(get_db),u=Depends(user)):
    job_for(db,job_id,u); return [serialize(c) for c in db.query(Candidate).filter_by(job_id=job_id).all()]
@router.get("/candidates/{candidate_id}")
def detail(candidate_id:int,db:Session=Depends(get_db),u=Depends(user)):
    c=db.get(Candidate,candidate_id); 
    if not c or c.job.owner_id!=u.id: raise HTTPException(404,"Candidate not found.")
    return serialize(c,True)
@router.post("/candidates/{candidate_id}/analyze")
def analyze(candidate_id:int,db:Session=Depends(get_db),u=Depends(user)):
    c=db.get(Candidate,candidate_id)
    if not c or c.job.owner_id!=u.id: raise HTTPException(404,"Candidate not found.")
    state=graph.invoke({"job_id":c.job_id,"candidate_id":c.id,"job_data":{"required_skills":c.job.required_skills or [],"preferred_skills":c.job.preferred_skills or [],"experience_required":c.job.experience_required,"education_required":c.job.education_required},"resume_text":c.raw_resume_text or ""})
    m=state["match_result"]; old=c.match
    if old: 
        for k,v in m.items(): setattr(old,k,v)
    else:
        db.add(Match(candidate_id=c.id,job_id=c.job_id,**m))
    c.status="analyzed"
    db.commit()
    return {"candidate":serialize(c,True),"match":m,"interview_questions":state.get("interview_questions",[]),"report":state.get("report")}
def serialize(c,detail=False):
    d={"id":c.id,"job_id":c.job_id,"name":c.name,"email":c.email,"phone":c.phone,"status":c.status,"skills":[s.skill_name for s in c.skills],"education":c.education or []}
    if detail: d.update({"experience":[{"role":e.role_title,"duration":e.duration,"description":e.description} for e in c.experience],"projects":[{"title":p.title,"description":p.description,"technologies":p.technologies_used or []} for p in c.projects],"match":None if not c.match else {"overall_score":c.match.overall_score,"skill_score":c.match.skill_score,"experience_score":c.match.experience_score,"education_score":c.match.education_score,"project_score":c.match.project_score,"certification_score":c.match.certification_score,"matching_skills":c.match.matching_skills or [],"missing_skills":c.match.missing_skills or [],"recommendation":c.match.recommendation,"explanation":c.match.explanation}})
    return d

@router.post("/candidates/{candidate_id}/match")
def match_candidate(candidate_id:int,db:Session=Depends(get_db),u=Depends(user)):
    return analyze(candidate_id,db,u)
