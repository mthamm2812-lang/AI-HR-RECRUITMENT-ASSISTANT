"""
Health-check route.

This is a real, working endpoint (not a placeholder) used to confirm the
FastAPI server is running and reachable from the frontend. It does not
touch the database or any AI component - those are wired in during
later phases.
"""
from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
def health_check():
    """Return basic service status information."""
    return {
        "status": "ok",
        "service": "ai-hr-recruitment-assistant-backend",
        "phase": "1 - project scaffolding",
    }
