from fastapi import APIRouter,Depends,Header,HTTPException
from sqlalchemy.orm import Session
from database.session import get_db
from models import Candidate,AnalysisReport
from api.routes.auth import current_user
router=APIRouter()
@router.post("/candidates/{candidate_id}")
def report(candidate_id:int,db:Session=Depends(get_db),authorization:str|None=Header(None)):
    u=current_user(db,authorization);c=db.get(Candidate,candidate_id)
    if not c or c.job.owner_id!=u.id: raise HTTPException(404,"Candidate not found.")
    m=c.match
    if not m: raise HTTPException(400,"Analyze the candidate before generating a report.")
    summary={"candidate":{"id":c.id,"name":c.name},"job":{"id":c.job_id},"score_breakdown":{"technical_skills":m.skill_score,"experience":m.experience_score,"education":m.education_score,"projects":m.project_score,"certifications":m.certification_score},"overall_score":m.overall_score,"recommendation":m.recommendation,"matching_skills":m.matching_skills or [],"missing_skills":m.missing_skills or [],"explanation":m.explanation,"human_review_required":True}
    r=AnalysisReport(job_id=c.job_id,candidate_id=c.id,summary_json=summary);db.add(r);db.commit();return summary
@router.get("/candidates/{candidate_id}")
def get_report(candidate_id:int,db:Session=Depends(get_db),authorization:str|None=Header(None)):
    u=current_user(db,authorization);c=db.get(Candidate,candidate_id)
    if not c or c.job.owner_id!=u.id: raise HTTPException(404,"Candidate not found.")
    r=db.query(AnalysisReport).filter_by(candidate_id=candidate_id).order_by(AnalysisReport.generated_at.desc()).first()
    if not r: raise HTTPException(404,"Report not found.")
    return r.summary_json
