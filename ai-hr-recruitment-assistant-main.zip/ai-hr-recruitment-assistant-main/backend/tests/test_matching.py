from services.matching_service import score_candidate
def test_scoring():
    j=type("J",(),{"required_skills":["Python","SQL"],"experience_required":None,"education_required":None})()
    r=score_candidate(j,{"skills":["Python"],"experience":[],"education":[],"projects":[],"certifications":[]})
    assert r["skill_score"]==50
    assert r["overall_score"]==20
    assert r["recommendation"]=="NOT RECOMMENDED"
