from services.extraction_service import skills
def test_skill_extraction():
    assert "Python" in skills("Python FastAPI SQL")
