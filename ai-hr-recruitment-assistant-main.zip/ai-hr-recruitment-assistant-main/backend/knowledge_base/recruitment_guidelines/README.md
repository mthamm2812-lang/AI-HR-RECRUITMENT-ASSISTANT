Add company-approved recruitment criteria here. Protected attributes must never influence ranking.
