Add approved interview guidelines here.
