"""Final assembled report snapshot for a candidate within a job."""
from sqlalchemy import JSON, Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database.base import Base


class AnalysisReport(Base):
    __tablename__ = "analysis_reports"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)

    generated_at = Column(DateTime(timezone=True), server_default=func.now())
    report_file_path = Column(String(500), nullable=True)
    summary_json = Column(JSON, nullable=True)

    job = relationship("Job", back_populates="analysis_reports")
    candidate = relationship("Candidate", back_populates="analysis_reports")
