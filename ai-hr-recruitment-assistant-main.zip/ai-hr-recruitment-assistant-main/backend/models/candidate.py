"""Candidate model - one uploaded resume, tied to one job."""
from sqlalchemy import JSON, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database.base import Base


class Candidate(Base):
    __tablename__ = "candidates"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)

    name = Column(String(255), nullable=True)
    email = Column(String(255), nullable=True, index=True)
    phone = Column(String(50), nullable=True)

    resume_file_path = Column(String(500), nullable=True)
    raw_resume_text = Column(Text, nullable=True)
    education = Column(JSON, nullable=True, default=list)

    # "uploaded" | "parsed" | "analyzed" | "error"
    status = Column(String(50), nullable=False, default="uploaded")

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    job = relationship("Job", back_populates="candidates")
    skills = relationship("CandidateSkill", back_populates="candidate", cascade="all, delete-orphan")
    experience = relationship(
        "CandidateExperience", back_populates="candidate", cascade="all, delete-orphan"
    )
    projects = relationship(
        "CandidateProject", back_populates="candidate", cascade="all, delete-orphan"
    )
    match = relationship(
        "Match", back_populates="candidate", uselist=False, cascade="all, delete-orphan"
    )
    interview_questions = relationship(
        "InterviewQuestion", back_populates="candidate", cascade="all, delete-orphan"
    )
    analysis_reports = relationship(
        "AnalysisReport", back_populates="candidate", cascade="all, delete-orphan"
    )
