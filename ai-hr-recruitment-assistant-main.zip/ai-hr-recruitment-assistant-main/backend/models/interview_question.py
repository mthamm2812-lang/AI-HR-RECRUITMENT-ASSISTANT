"""Generated interview question tied to a specific candidate and job."""
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database.base import Base


class InterviewQuestion(Base):
    __tablename__ = "interview_questions"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)

    # technical | resume_based | project | behavioral | skill_gap
    category = Column(String(50), nullable=False)
    difficulty = Column(String(50), nullable=True)  # easy | medium | hard
    question_text = Column(Text, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    candidate = relationship("Candidate", back_populates="interview_questions")
    job = relationship("Job", back_populates="interview_questions")
