"""
Candidate-job match/score result.

One-to-one with Candidate (a candidate is only ever matched against
the single job they were uploaded for in this schema), enforced with
unique=True on candidate_id. job_id is kept alongside for simpler
querying ("all matches for this job") without a join.
"""
from sqlalchemy import JSON, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database.base import Base


class Match(Base):
    __tablename__ = "matches"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), unique=True, nullable=False)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)

    overall_score = Column(Float, nullable=True)
    skill_score = Column(Float, nullable=True)
    experience_score = Column(Float, nullable=True)
    education_score = Column(Float, nullable=True)
    project_score = Column(Float, nullable=True)
    certification_score = Column(Float, nullable=True)

    matching_skills = Column(JSON, nullable=True, default=list)
    missing_skills = Column(JSON, nullable=True, default=list)
    strengths = Column(JSON, nullable=True, default=list)
    weaknesses = Column(JSON, nullable=True, default=list)

    # "SHORTLIST" | "REVIEW" | "NOT RECOMMENDED"
    recommendation = Column(String(50), nullable=True)
    explanation = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    candidate = relationship("Candidate", back_populates="match")
    job = relationship("Job", back_populates="matches")
