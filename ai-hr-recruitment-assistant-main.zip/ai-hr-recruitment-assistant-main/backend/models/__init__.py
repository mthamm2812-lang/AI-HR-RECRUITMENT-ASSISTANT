"""
SQLAlchemy ORM models package.

Importing this package registers all 9 tables on Base.metadata, which
database/init_db.py relies on to create every table in one call.
It also lets other modules do `from models import User, Job, ...`.
"""
from models.analysis_report import AnalysisReport
from models.candidate import Candidate
from models.candidate_experience import CandidateExperience
from models.candidate_project import CandidateProject
from models.candidate_skill import CandidateSkill
from models.interview_question import InterviewQuestion
from models.job import Job
from models.match import Match
from models.user import User

__all__ = [
    "User",
    "Job",
    "Candidate",
    "CandidateSkill",
    "CandidateExperience",
    "CandidateProject",
    "Match",
    "InterviewQuestion",
    "AnalysisReport",
]
