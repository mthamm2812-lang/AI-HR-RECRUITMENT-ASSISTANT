"""Project entry extracted from a candidate's resume."""
from sqlalchemy import JSON, Column, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from database.base import Base


class CandidateProject(Base):
    __tablename__ = "candidate_projects"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)

    title = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    technologies_used = Column(JSON, nullable=True, default=list)

    candidate = relationship("Candidate", back_populates="projects")
