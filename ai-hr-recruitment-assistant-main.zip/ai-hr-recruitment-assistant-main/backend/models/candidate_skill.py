"""Individual skill extracted from a candidate's resume."""
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from database.base import Base


class CandidateSkill(Base):
    __tablename__ = "candidate_skills"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)

    skill_name = Column(String(255), nullable=False)
    # "programming_language" | "tool" | "technical" | "soft"
    skill_type = Column(String(50), nullable=True)

    candidate = relationship("Candidate", back_populates="skills")
