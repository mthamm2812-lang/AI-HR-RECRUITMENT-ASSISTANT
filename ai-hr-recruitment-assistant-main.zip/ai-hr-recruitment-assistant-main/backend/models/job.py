"""Job posting model."""
from sqlalchemy import JSON, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database.base import Base


class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    job_title = Column(String(255), nullable=False)
    raw_description_text = Column(Text, nullable=True)
    source_file_path = Column(String(500), nullable=True)

    required_skills = Column(JSON, nullable=True, default=list)
    preferred_skills = Column(JSON, nullable=True, default=list)
    experience_required = Column(String(100), nullable=True)
    education_required = Column(String(255), nullable=True)
    responsibilities = Column(JSON, nullable=True, default=list)
    certifications_required = Column(JSON, nullable=True, default=list)
    technical_requirements = Column(JSON, nullable=True, default=list)

    status = Column(String(50), nullable=False, default="draft")  # draft | active | closed

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    owner = relationship("User", back_populates="jobs")
    candidates = relationship("Candidate", back_populates="job", cascade="all, delete-orphan")
    matches = relationship("Match", back_populates="job", cascade="all, delete-orphan")
    interview_questions = relationship(
        "InterviewQuestion", back_populates="job", cascade="all, delete-orphan"
    )
    analysis_reports = relationship(
        "AnalysisReport", back_populates="job", cascade="all, delete-orphan"
    )
