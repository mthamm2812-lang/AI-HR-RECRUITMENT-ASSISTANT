from langchain_core.tools import tool
from services.pdf_service import extract_pdf
from services.rag_service import retrieve
from services.matching_service import score_candidate
@tool
def parse_resume(path:str)->str:
    """Extract text from a resume PDF path."""
    return extract_pdf(path)
@tool
def parse_job_description(path:str)->str:
    """Extract text from a job-description PDF path."""
    return extract_pdf(path)
@tool
def search_knowledge_base(query:str)->list:
    """Retrieve recruitment knowledge relevant to a query."""
    return retrieve(query)
@tool
def calculate_candidate_match(job_json:dict,candidate_json:dict)->dict:
    """Calculate transparent job-relevant candidate score."""
    return score_candidate(type("J",(),job_json)(),candidate_json)
@tool
def generate_interview_questions(job_json:dict,candidate_json:dict,missing_skills:list)->list:
    """Generate personalized interview questions using configured LLM."""
    from services.llm_service import interview_questions
    return interview_questions(job_json,candidate_json,missing_skills) or []
@tool
def save_candidate_result(result:dict)->dict:
    """Return a validated candidate result for persistence by the API layer."""
    return result
@tool
def retrieve_candidate_information(candidate_json:dict)->dict:
    """Return candidate information without protected attributes."""
    return {k:v for k,v in candidate_json.items() if k not in {"religion","caste","gender","disability","marital_status","race","ethnicity","political_affiliation"}}
TOOLS=[parse_resume,parse_job_description,search_knowledge_base,calculate_candidate_match,generate_interview_questions,save_candidate_result,retrieve_candidate_information]
