"""Pydantic response models for health/status endpoints."""
from typing import List

from pydantic import BaseModel


class DBHealthResponse(BaseModel):
    status: str
    database_url_type: str
    tables_found: List[str]
    table_count: int
