"""
Pydantic schemas package.

Phase 2 adds only schemas/health.py, used by the /api/db-health
route. Request/response schemas for jobs, candidates, matches, etc.
are added starting Phase 3's dependent phases (job/resume modules,
Phase 13 REST API).
"""
