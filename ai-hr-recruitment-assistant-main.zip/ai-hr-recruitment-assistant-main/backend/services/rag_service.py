from pathlib import Path
import os
KB=Path(__file__).resolve().parent.parent/"knowledge_base"
def retrieve(query,k=4):
    # Lightweight lexical retrieval always works; Chroma ingestion is available when dependencies are installed.
    words={w.lower() for w in query.split() if len(w)>3}
    hits=[]
    for p in KB.rglob("*.txt"):
        t=p.read_text(errors="ignore")
        score=sum(1 for w in words if w in t.lower())
        if score: hits.append((score,p,t[:3000]))
    for p in KB.rglob("*.md"):
        t=p.read_text(errors="ignore")
        score=sum(1 for w in words if w in t.lower())
        if score: hits.append((score,p,t[:3000]))
    hits.sort(reverse=True,key=lambda x:x[0])
    return [{"source":str(p.relative_to(KB)),"content":t} for _,p,t in hits[:k]]
def ingest_chroma():
    try:
        import chromadb
        client=chromadb.PersistentClient(path=os.getenv("CHROMA_DIR","./chroma_db"))
        col=client.get_or_create_collection("recruitment_knowledge")
        docs=[]; ids=[]
        for p in KB.rglob("*"):
            if p.suffix.lower() in {".txt",".md"}:
                docs.append(p.read_text(errors="ignore")); ids.append(str(p.relative_to(KB)))
        if docs: col.upsert(ids=ids,documents=docs)
        return len(docs)
    except Exception as e:
        raise RuntimeError(f"ChromaDB ingestion failed: {e}")
