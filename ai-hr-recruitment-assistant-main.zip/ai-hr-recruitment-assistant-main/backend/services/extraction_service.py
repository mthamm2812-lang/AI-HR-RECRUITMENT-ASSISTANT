import re
PROTECTED={"religion","caste","gender","sex","disability","marital status","race","ethnicity","political affiliation"}
SKILL_RE=re.compile(r"(?i)\b(python|java|c\+\+|c#|javascript|typescript|react|react\.js|node\.js|fastapi|django|flask|sql|mysql|postgresql|mongodb|git|docker|kubernetes|aws|azure|gcp|machine learning|deep learning|tensorflow|pytorch|opencv|langchain|langgraph|html|css)\b")
def skills(text):
    vals=[]
    for m in SKILL_RE.findall(text):
        v=m.replace(".js",".js")
        if v.lower() not in [x.lower() for x in vals]: vals.append(v)
    return vals
def name_from_text(text):
    for line in text.split(". "):
        s=line.strip()
        if s and len(s.split())<=5 and re.match(r"^[A-Za-z][A-Za-z .'-]+$",s):
            return s
    return None
def analyze_resume(text):
    lower=text.lower()
    yrs=re.search(r"(\d+(?:\.\d+)?)\+?\s*(?:years?|yrs?)\s*(?:of)?\s*(?:experience|exp)",lower)
    email=re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+",text)
    phone=re.search(r"(?:\+?\d[\d\s().-]{8,}\d)",text)
    return {"name":name_from_text(text),"email":email.group(0) if email else None,
            "phone":phone.group(0).strip() if phone else None,
            "skills":skills(text),"education":re.findall(r"(?i)(b\.?e\.?|b\.?tech|m\.?e\.?|m\.?tech|bsc|msc|bachelor|master|phd)[^\n,.]{0,100}",text),
            "experience":[{"role_title":"Extracted experience","duration":(yrs.group(1)+" years") if yrs else None,"description":"Experience evidence extracted from resume text."}] if yrs else [],
            "projects":[],"certifications":[],"relevant_achievements":[],"protected_attributes_detected":[]}
def analyze_jd(text):
    s=skills(text)
    yrs=re.search(r"(\d+(?:\.\d+)?)\+?\s*(?:years?|yrs?)",text,re.I)
    return {"job_title":text.splitlines()[0][:255] if text.splitlines() else "Untitled Position",
            "required_skills":s,"preferred_skills":[],"education_required":None,
            "experience_required":(yrs.group(1)+" years") if yrs else None,
            "responsibilities":[],"certifications_required":[],"technical_requirements":s}
