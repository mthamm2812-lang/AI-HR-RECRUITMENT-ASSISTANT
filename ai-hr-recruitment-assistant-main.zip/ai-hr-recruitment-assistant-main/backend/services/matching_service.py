def score_candidate(job,cand):
    req={x.lower() for x in (job.required_skills or [])}; cs={x.lower() for x in (cand.get("skills") or [])}
    matched=sorted(req&cs); missing=sorted(req-cs)
    skill=100 if not req else len(matched)/len(req)*100
    exp=100 if not job.experience_required else (100 if cand.get("experience") else 0)
    edu=100 if not job.education_required else (100 if cand.get("education") else 0)
    proj=100 if cand.get("projects") else 0
    cert=100 if cand.get("certifications") else 0
    total=round(skill*.40+exp*.25+edu*.15+proj*.10+cert*.10,2)
    rec="SHORTLIST" if total>=80 else ("REVIEW" if total>=60 else "NOT RECOMMENDED")
    return {"matching_skills":matched,"missing_skills":missing,"skill_score":round(skill,2),
            "experience_score":round(exp,2),"education_score":round(edu,2),"project_score":round(proj,2),
            "certification_score":round(cert,2),"overall_score":total,"recommendation":rec,
            "explanation":f"Score is based only on job-relevant criteria: {len(matched)}/{len(req) if req else 0} required skills matched."}
