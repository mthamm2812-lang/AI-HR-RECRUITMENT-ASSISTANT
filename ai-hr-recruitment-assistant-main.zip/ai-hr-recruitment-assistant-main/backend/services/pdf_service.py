from pathlib import Path
import fitz
from fastapi import UploadFile, HTTPException
import os, re, uuid
BASE=Path(__file__).resolve().parent.parent/"uploads"
MAX_MB=int(os.getenv("UPLOAD_MAX_MB","10"))
def validate_pdf(upload:UploadFile):
    if not upload.filename or not upload.filename.lower().endswith(".pdf"):
        raise HTTPException(400,"Only PDF files are accepted.")
def extract_pdf(path:Path)->str:
    try:
        doc=fitz.open(path)
        text="\n".join(page.get_text() for page in doc).strip()
        doc.close()
        if not text: raise HTTPException(422,"The PDF contains no extractable text.")
        return re.sub(r"\s+"," ",text)
    except HTTPException: raise
    except Exception:
        raise HTTPException(422,"Could not read or extract text from this PDF.")
async def save_upload(upload:UploadFile, category:str)->tuple[Path,str]:
    validate_pdf(upload)
    data=await upload.read()
    if not data: raise HTTPException(400,"Uploaded file is empty.")
    if len(data)>MAX_MB*1024*1024: raise HTTPException(413,f"File exceeds {MAX_MB} MB limit.")
    target=BASE/category
    target.mkdir(parents=True,exist_ok=True)
    safe=re.sub(r"[^A-Za-z0-9._-]","_",Path(upload.filename).name)
    path=target/f"{uuid.uuid4().hex}_{safe}"
    path.write_bytes(data)
    # validate PDF immediately
    text=extract_pdf(path)
    return path,text
