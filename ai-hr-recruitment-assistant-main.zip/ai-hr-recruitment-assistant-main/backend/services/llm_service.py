import os, json
def available(): return bool(os.getenv("OPENAI_API_KEY"))
def structured_analysis(text,kind):
    if not available(): return None
    try:
        from langchain_openai import ChatOpenAI
        from langchain_core.prompts import ChatPromptTemplate
        from pydantic import BaseModel
        class Result(BaseModel): data: dict
        llm=ChatOpenAI(model=os.getenv("OPENAI_MODEL","gpt-4o-mini"),temperature=0)
        prompt=ChatPromptTemplate.from_messages([("system","Extract only facts present in the document. Never infer protected attributes or invent facts. Return JSON in data."),("human",f"Type: {kind}\nDocument:\n{text}")])
        r=llm.with_structured_output(Result).invoke(prompt.format_messages())
        return r.data
    except Exception:
        return None
def interview_questions(job,cand,missing):
    if not available(): return None
    from langchain_openai import ChatOpenAI
    from langchain_core.prompts import ChatPromptTemplate
    class Q: pass
    prompt=ChatPromptTemplate.from_messages([("system","Generate 10 concise personalized HR interview questions. Categories: Technical, Project, Experience, Behavioral, Job-specific. Use only provided facts."),("human",f"Job skills: {job.required_skills}\nCandidate skills: {cand.get('skills')}\nProjects: {cand.get('projects')}\nGaps: {missing}")])
    msg=ChatOpenAI(model=os.getenv("OPENAI_MODEL","gpt-4o-mini"),temperature=.2).invoke(prompt.format_messages())
    return [x.strip("- ") for x in msg.content.splitlines() if x.strip()][:10]
