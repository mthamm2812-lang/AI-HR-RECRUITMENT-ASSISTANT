"""
services/__init__.py package.

Not yet implemented. This package is wired up in Phase 5-13 (business logic services) of the
AI HR Recruitment Assistant build (see project README / design doc).
Phase 1 only creates the folder + package marker so imports resolve
cleanly as later phases are added.
"""
