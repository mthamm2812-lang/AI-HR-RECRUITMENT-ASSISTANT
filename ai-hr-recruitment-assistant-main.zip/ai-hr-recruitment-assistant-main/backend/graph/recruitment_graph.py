from typing import TypedDict,Any
from langgraph.graph import StateGraph,END
from services.extraction_service import analyze_jd,analyze_resume
from services.matching_service import score_candidate
from services.rag_service import retrieve
from services.llm_service import interview_questions
class RecruitmentState(TypedDict, total=False):
    job_id:int; candidate_id:int; job_data:dict; resume_text:str; candidate_data:dict; retrieved_context:list
    match_result:dict; overall_score:float; recommendation:str; interview_questions:list; report:dict; errors:list; status:str
def job_analysis(s):
    s["job_data"]=s.get("job_data") or {}; s["status"]="job_analyzed"; return s
def resume_analysis(s):
    s["candidate_data"]=analyze_resume(s["resume_text"]); s["status"]="resume_analyzed"; return s
def rag(s):
    q=" ".join(s["job_data"].get("required_skills",[])); s["retrieved_context"]=retrieve(q); s["status"]="rag_retrieved"; return s
def matching(s):
    s["match_result"]=score_candidate(type("J",(),s["job_data"])(),s["candidate_data"]); s["overall_score"]=s["match_result"]["overall_score"]; s["recommendation"]=s["match_result"]["recommendation"]; s["status"]="matched"; return s
def interviews(s):
    q=interview_questions(s["job_data"],s["candidate_data"],s["match_result"]["missing_skills"])
    s["interview_questions"]=q or [f"Explain your experience with {x} and how you used it." for x in s["match_result"]["matching_skills"][:5]]
    s["status"]="interview_generated"; return s
def report(s):
    s["report"]={"summary":s["match_result"]["explanation"],"score":s["overall_score"],"recommendation":s["recommendation"],"matched_skills":s["match_result"]["matching_skills"],"missing_skills":s["match_result"]["missing_skills"],"rag_sources":[x["source"] for x in s.get("retrieved_context",[])]}; s["status"]="completed"; return s
def build_graph():
    g=StateGraph(RecruitmentState)
    for n,f in [("job_analysis",job_analysis),("resume_analysis",resume_analysis),("rag_retrieval",rag),("matching",matching),("interviews",interviews),("report",report)]: g.add_node(n,f)
    g.set_entry_point("job_analysis"); g.add_edge("job_analysis","resume_analysis"); g.add_edge("resume_analysis","rag_retrieval"); g.add_edge("rag_retrieval","matching"); g.add_edge("matching","interviews"); g.add_edge("interviews","report"); g.add_edge("report",END)
    return g.compile()
graph=build_graph()
