"""
SQLAlchemy declarative base.

Every ORM model imports Base from here so they all register on the
same MetaData object. database/init_db.py uses that shared metadata
to create all tables in one call.
"""
from sqlalchemy.orm import declarative_base

Base = declarative_base()
