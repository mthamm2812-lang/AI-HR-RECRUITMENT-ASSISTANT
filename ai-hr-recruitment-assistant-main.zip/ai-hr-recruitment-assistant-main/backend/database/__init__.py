"""
Database package.

Implemented in Phase 2:
- base.py    -> shared SQLAlchemy declarative Base
- session.py -> engine, SessionLocal, get_db() FastAPI dependency
- init_db.py -> creates all tables from the models package
"""
