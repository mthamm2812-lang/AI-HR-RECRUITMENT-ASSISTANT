import logging
import models
from database.base import Base
from database.session import engine
logger=logging.getLogger(__name__)
def init_db():
    Base.metadata.create_all(bind=engine)
    logger.info("PostgreSQL tables verified/created successfully.")
