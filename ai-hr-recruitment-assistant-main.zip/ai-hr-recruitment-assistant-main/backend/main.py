import logging,os
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from database.init_db import init_db
from api.routes import health,db_health,auth,jobs,candidates,dashboard,interview,reports,knowledge
logging.basicConfig(level=logging.INFO)
app=FastAPI(title="AI HR Recruitment Assistant API",version="1.0.0",description="AI-assisted, explainable HR recruitment platform with human review.")
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in os.getenv("CORS_ORIGINS","http://localhost:5173").split(",") if x.strip()],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
for r,prefix,tags in [(health.router,"/api",["health"]),(db_health.router,"/api",["database"]),(auth.router,"/api/auth",["authentication"]),(jobs.router,"/api/jobs",["jobs"]),(candidates.router,"/api",["candidates"]),(dashboard.router,"/api/dashboard",["dashboard"]),(interview.router,"/api/interview",["interview"]),(reports.router,"/api/reports",["reports"]),(knowledge.router,"/api/knowledge-base",["knowledge-base"])]: app.include_router(r,prefix=prefix,tags=tags)
@app.on_event("startup")
def startup(): init_db()
@app.get("/")
def root(): return {"message":"AI HR Recruitment Assistant API is running.","docs":"/docs"}
