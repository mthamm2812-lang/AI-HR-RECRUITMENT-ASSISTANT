import { useState } from 'react'
import api from '../services/api.js'

/**
 * Phase 1 homepage.
 *
 * This is intentionally simple - it exists to prove the React app and
 * FastAPI backend can actually talk to each other over HTTP, using a
 * real axios call to a real endpoint (no mocked/fake data). The full
 * HR dashboard replaces this in Phase 14.
 */
function Home() {
  const [status, setStatus] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const checkBackend = async () => {
    setLoading(true)
    setError(null)
    setStatus(null)
    try {
      const response = await api.get('/api/health')
      setStatus(response.data)
    } catch (err) {
      setError(
        'Could not reach the backend. Make sure it is running and that ' +
          'VITE_API_BASE_URL points to the right address.'
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="home-page">
      <header className="home-header">
        <h1>AI HR Recruitment Assistant</h1>
        <p>Phase 1 scaffold — frontend and backend skeletons are in place.</p>
      </header>

      <section className="home-card">
        <h2>Backend Connectivity Check</h2>
        <p>
          This calls the FastAPI health-check endpoint to confirm the two
          apps can talk to each other.
        </p>
        <button onClick={checkBackend} disabled={loading}>
          {loading ? 'Checking...' : 'Check Backend Health'}
        </button>

        {status && (
          <div className="status-box status-ok">
            <div><strong>Status:</strong> {status.status}</div>
            <div><strong>Service:</strong> {status.service}</div>
            <div><strong>Phase:</strong> {status.phase}</div>
          </div>
        )}

        {error && <div className="status-box status-error">{error}</div>}
      </section>
    </div>
  )
}

export default Home
