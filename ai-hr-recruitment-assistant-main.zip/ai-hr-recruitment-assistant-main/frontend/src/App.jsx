import {
  Routes,
  Route,
  Navigate,
  Link,
  useNavigate,
  useParams,
} from "react-router-dom";

import { useEffect, useState } from "react";
import api from "./services/api";
import "./App.css";

const auth = () => localStorage.getItem("token");

/* =========================
   Layout
========================= */

function Layout({ children }) {
  const nav = useNavigate();

  function logout() {
    localStorage.clear();
    nav("/login");
  }

  return (
    <div className="app">
      <aside>
        <h2>AI HR</h2>
        <p className="muted">Recruitment Assistant</p>

        <nav>
          <Link to="/">Dashboard</Link>
          <Link to="/jobs">Jobs</Link>
        </nav>

        <button className="logout" onClick={logout}>
          Logout
        </button>
      </aside>

      <main>{children}</main>
    </div>
  );
}

/* =========================
   Login / Register
========================= */

function Login() {
  const nav = useNavigate();

  const [register, setRegister] = useState(false);

  const [f, setF] = useState({
    email: "",
    password: "",
    full_name: "",
  });

  const [e, setE] = useState("");

  async function go(x) {
    x.preventDefault();
    setE("");

    try {
      const r = await api.post(
        register ? "/api/auth/register" : "/api/auth/login",
        f
      );

      localStorage.setItem("token", r.data.token);

      nav("/");
    } catch (error) {
      setE(
        error.response?.data?.detail ||
          "Request failed. Please try again."
      );
    }
  }

  return (
    <div className="auth">
      <form onSubmit={go}>
        <h1>
          {register ? "Create HR account" : "HR Login"}
        </h1>

        {register && (
          <input
            placeholder="Full name"
            value={f.full_name}
            onChange={(e) =>
              setF({
                ...f,
                full_name: e.target.value,
              })
            }
          />
        )}

        <input
          placeholder="Email"
          type="email"
          value={f.email}
          onChange={(e) =>
            setF({
              ...f,
              email: e.target.value,
            })
          }
        />

        <input
          type="password"
          placeholder="Password"
          value={f.password}
          onChange={(e) =>
            setF({
              ...f,
              password: e.target.value,
            })
          }
        />

        {e && <div className="error">{e}</div>}

        <button type="submit">
          {register ? "Register" : "Login"}
        </button>

        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setRegister(!register);
            setE("");
          }}
        >
          {register
            ? "Already have an account? Login"
            : "Create an account"}
        </a>
      </form>
    </div>
  );
}

/* =========================
   Dashboard
========================= */

function Dashboard() {
  const [d, setD] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchDashboard() {
      try {
        const r = await api.get("/api/dashboard");
        setD(r.data);
      } catch (error) {
        setError(
          error.response?.data?.detail ||
            "Unable to load dashboard."
        );
      }
    }

    fetchDashboard();
  }, []);

  if (error) {
    return (
      <Layout>
        <h1>HR Dashboard</h1>
        <div className="error">{error}</div>
      </Layout>
    );
  }

  if (!d) {
    return (
      <Layout>
        <h1>Dashboard</h1>
        <p>Loading...</p>
      </Layout>
    );
  }

  return (
    <Layout>
      <h1>HR Dashboard</h1>

      <p className="muted">
        AI recommendations support HR review; they do not
        make the final hiring decision.
      </p>

      <div className="cards">
        {[
          ["Jobs", d.total_jobs],
          ["Candidates", d.total_candidates],
          ["Shortlisted", d.shortlisted],
          ["Review", d.review],
          ["Not recommended", d.not_recommended],
        ].map((x) => (
          <div className="card" key={x[0]}>
            <b>{x[0]}</b>
            <strong>{x[1]}</strong>
          </div>
        ))}
      </div>

      <section className="panel">
        <h2>Candidate Ranking</h2>

        {d.rankings?.length > 0 ? (
          d.rankings.map((x, i) => (
            <div className="row" key={x.candidate_id || i}>
              <span>
                #{i + 1}{" "}
                {x.name ||
                  "Candidate #" + x.candidate_id}
              </span>

              <b>
                {typeof x.score === "number"
                  ? x.score.toFixed(1)
                  : "0.0"}{" "}
                — {x.recommendation}
              </b>
            </div>
          ))
        ) : (
          <p className="muted">
            No candidate rankings available yet.
          </p>
        )}
      </section>
    </Layout>
  );
}

/* =========================
   Jobs
========================= */

function Jobs() {
  const nav = useNavigate();

  const [jobs, setJobs] = useState([]);
  const [file, setFile] = useState(null);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  async function load() {
    try {
      const r = await api.get("/api/jobs");
      setJobs(r.data);
    } catch (error) {
      setMsg(
        error.response?.data?.detail ||
          "Unable to load jobs."
      );
    }
  }

  /*
    IMPORTANT:
    Do NOT write:
    useEffect(load, []);

    because load() returns a Promise.

    This is the corrected version.
  */

  useEffect(() => {
    load();
  }, []);

  async function upload() {
    if (!file) {
      setMsg("Please select a PDF file first.");
      return;
    }

    setLoading(true);
    setMsg("");

    try {
      const fd = new FormData();

      fd.append("file", file);

      await api.post("/api/jobs/upload", fd);

      setMsg(
        "Job description uploaded and analyzed successfully."
      );

      setFile(null);

      await load();
    } catch (error) {
      setMsg(
        error.response?.data?.detail ||
          "Job description upload failed."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout>
      <h1>Jobs</h1>

      <div className="panel">
        <h2>Upload Job Description</h2>

        <input
          type="file"
          accept=".pdf"
          onChange={(e) =>
            setFile(e.target.files?.[0] || null)
          }
        />

        <button
          onClick={upload}
          disabled={loading}
        >
          {loading
            ? "Uploading..."
            : "Upload & Analyze"}
        </button>

        {msg && <p>{msg}</p>}
      </div>

      {jobs.length === 0 ? (
        <div className="panel">
          <p className="muted">
            No jobs available. Upload a Job Description PDF
            to create your first job.
          </p>
        </div>
      ) : (
        jobs.map((j) => (
          <div className="panel" key={j.id}>
            <h2>{j.job_title}</h2>

            <p>
              <strong>Required skills:</strong>{" "}
              {(j.required_skills || []).join(", ") ||
                "None extracted"}
            </p>

            <button
              onClick={() =>
                nav("/jobs/" + j.id)
              }
            >
              Manage Candidates
            </button>
          </div>
        ))
      )}
    </Layout>
  );
}

/* =========================
   Job Detail
========================= */

function JobDetail() {
  const { id } = useParams();

  const [f, setF] = useState(null);
  const [c, setC] = useState([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  async function loadJob() {
    try {
      const r = await api.get("/api/jobs/" + id);
      setF(r.data);
    } catch (error) {
      setMsg(
        error.response?.data?.detail ||
          "Unable to load job."
      );
    }
  }

  async function loadCandidates() {
    try {
      const r = await api.get(
        "/api/jobs/" + id + "/candidates"
      );

      setC(r.data);
    } catch (error) {
      setMsg(
        error.response?.data?.detail ||
          "Unable to load candidates."
      );
    }
  }

  useEffect(() => {
    async function loadData() {
      await loadJob();
      await loadCandidates();
    }

    loadData();
  }, [id]);

  async function upload(e) {
    const files = [...(e.target.files || [])];

    if (files.length === 0) {
      return;
    }

    setLoading(true);
    setMsg("");

    try {
      const fd = new FormData();

      files.forEach((x) => {
        fd.append("files", x);
      });

      await api.post(
        "/api/jobs/" + id + "/resumes",
        fd
      );

      setMsg("Resumes uploaded successfully.");

      await loadCandidates();
    } catch (error) {
      setMsg(
        error.response?.data?.detail ||
          "Resume upload failed."
      );
    } finally {
      setLoading(false);
    }
  }

  async function analyze(cid) {
    setLoading(true);
    setMsg("");

    try {
      const r = await api.post(
        "/api/candidates/" + cid + "/analyze"
      );

      const score =
        r.data?.match?.overall_score;

      setMsg(
        "Candidate analyzed successfully. Score: " +
          (score ?? "N/A")
      );

      await loadCandidates();
    } catch (error) {
      setMsg(
        error.response?.data?.detail ||
          "Candidate analysis failed."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout>
      <h1>{f?.job_title || "Job"}</h1>

      <div className="panel">
        <h2>Upload Resumes</h2>

        <input
          type="file"
          multiple
          accept=".pdf"
          onChange={upload}
          disabled={loading}
        />

        {msg && <p>{msg}</p>}
      </div>

      <div className="panel">
        <h2>Candidates</h2>

        {c.length === 0 ? (
          <p className="muted">
            No candidates uploaded yet.
          </p>
        ) : (
          c.map((x) => (
            <div className="row" key={x.id}>
              <span>
                {x.name || "Candidate #" + x.id}
                {" — "}
                {(x.skills || []).join(", ")}
              </span>

              <button
                onClick={() => analyze(x.id)}
                disabled={loading}
              >
                Analyze & Match
              </button>
            </div>
          ))
        )}
      </div>
    </Layout>
  );
}

/* =========================
   App
========================= */

function App() {
  return auth() ? (
    <Routes>
      <Route
        path="/login"
        element={<Navigate to="/" replace />}
      />

      <Route
        path="/"
        element={<Dashboard />}
      />

      <Route
        path="/jobs"
        element={<Jobs />}
      />

      <Route
        path="/jobs/:id"
        element={<JobDetail />}
      />

      <Route
        path="*"
        element={<Navigate to="/" replace />}
      />
    </Routes>
  ) : (
    <Routes>
      <Route
        path="/login"
        element={<Login />}
      />

      <Route
        path="*"
        element={<Navigate to="/login" replace />}
      />
    </Routes>
  );
}

export default App;